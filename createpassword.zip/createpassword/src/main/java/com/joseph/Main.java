package com.joseph;

import org.mindrot.jbcrypt.BCrypt;

public class Main {
    public static void main(String[] args) {
        String password = "123456"; // Replace it with your own password
        String pepper = "wkuposts2024";
        String hashed = BCrypt.hashpw(password, BCrypt.gensalt(12) + pepper);
        System.out.println(hashed);
    }
}